﻿export default function Reports() {
  return <div>Reports coming soon.</div>
}
